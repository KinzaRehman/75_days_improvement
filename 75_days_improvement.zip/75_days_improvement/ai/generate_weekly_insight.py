"""
generate_weekly_insight.py
------------------------------------------------------------------
Turns a week of tracker data into a short, personalized narrative
insight - the kind of thing you'd surface in a "weekly recap" email
or in-app card.

Two modes, same interface:
  --mode mock (default) - a deterministic, rule-based generator. No API
      key, no network call, no extra dependency. This is what runs in
      CI and what a reviewer can run immediately with zero setup.
  --mode live - builds the same underlying stats, then sends a compact
      prompt to Claude (via the `anthropic` package) and prints the
      model's actual narrative. Requires ANTHROPIC_API_KEY to be set.

The point of structuring it this way: the prompt-construction and the
stats pipeline are identical in both modes, so switching from "demo
without a key" to "real LLM call" is a one-flag change, not a rewrite.

Usage:
    python generate_weekly_insight.py --input ../analytics/sample_data/sample_export.csv
    python generate_weekly_insight.py --input ../analytics/sample_data/sample_export.csv --mode live
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Reuse the same CSV-loading + summarizing logic as the analytics
# module instead of duplicating it here.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "analytics"))
from analyze_progress import load_export, summarize  # noqa: E402


def last_n_days(df, n: int = 7):
    return df.tail(n)


def build_prompt(summary: dict, challenge_label: str) -> str:
    mood_lines = "\n".join(f"- {mood}: {count}x" for mood, count in summary["mood_breakdown"].items())
    return f"""You are a supportive, no-nonsense coach writing a short weekly recap for someone
doing the {challenge_label} challenge. Use their real numbers below. Keep it to
3-4 sentences: one honest observation, one thing to notice (not judge), and one
concrete, small suggestion for the coming week. No toxic positivity, no guilt-tripping.

This week's data:
- Days completed this week: {summary['completed_days']} / {summary['total_days_logged']}
- Completion rate: {summary['completion_rate']}%
- Current streak: {summary['current_streak']} days
- Average energy (1-10): {summary['avg_energy_overall']}
- Energy on completed vs. missed days: {summary['avg_energy_on_completed_days']} vs {summary['avg_energy_on_missed_days']}
- Mood log:
{mood_lines or '- (no moods logged this week)'}
"""


def generate_mock_insight(summary: dict, challenge_label: str) -> str:
    """
    Deterministic, rule-based fallback - no API key or network needed.
    Deliberately mirrors the tone/structure the live prompt asks the
    model for, so the two modes feel like the same feature.
    """
    rate = summary["completion_rate"]
    streak = summary["current_streak"]
    energy_gap = None
    if summary["avg_energy_on_completed_days"] is not None and summary["avg_energy_on_missed_days"] is not None:
        energy_gap = round(summary["avg_energy_on_completed_days"] - summary["avg_energy_on_missed_days"], 1)

    if rate >= 85:
        headline = f"Strong week on {challenge_label} - {rate}% of days completed and a {streak}-day streak going."
    elif rate >= 60:
        headline = f"Solid but uneven week on {challenge_label}: {rate}% completion, current streak sitting at {streak} days."
    else:
        headline = f"A rougher week on {challenge_label} ({rate}% completion) - worth noticing, not judging."

    if energy_gap is not None and energy_gap > 0.5:
        observation = (
            f"Energy ran about {energy_gap} points higher on days you completed the challenge than on days "
            "you didn't - that's a real, measurable pattern, not just a feeling."
        )
    else:
        observation = "Energy looked fairly similar whether or not the day was completed - worth watching if that holds."

    if rate < 60:
        suggestion = "For next week, try picking one single non-negotiable task instead of all of them on your hardest days."
    else:
        suggestion = "For next week, keep the same rhythm - maybe pre-plan tomorrow's workout tonight to protect the streak."

    return f"{headline} {observation} {suggestion}"


def generate_live_insight(summary: dict, challenge_label: str) -> str:
    try:
        import anthropic
    except ImportError as exc:
        raise SystemExit(
            "Live mode needs the `anthropic` package. Install it with:\n"
            "  pip install -r requirements.txt"
        ) from exc

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise SystemExit("Set ANTHROPIC_API_KEY in your environment to use --mode live.")

    client = anthropic.Anthropic(api_key=api_key)
    prompt = build_prompt(summary, challenge_label)
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=300,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True, help="Path to an exported CSV from the tracker")
    parser.add_argument("--mode", choices=["mock", "live"], default="mock")
    parser.add_argument("--days", type=int, default=7, help="How many recent days to summarize")
    args = parser.parse_args()

    df = load_export(args.input)
    if df.empty:
        raise SystemExit(f"No rows found in {args.input}")

    challenge_label = str(df["Challenge"].iloc[0]) if "Challenge" in df.columns else "Challenge"
    week_df = last_n_days(df, args.days)
    summary = summarize(week_df)

    if args.mode == "live":
        insight = generate_live_insight(summary, challenge_label)
    else:
        insight = generate_mock_insight(summary, challenge_label)

    print(f"\n=== Weekly insight ({args.mode} mode) ===")
    print(insight)


if __name__ == "__main__":
    main()
