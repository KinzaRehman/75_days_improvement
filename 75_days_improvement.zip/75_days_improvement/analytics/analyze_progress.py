"""
analyze_progress.py
------------------------------------------------------------------
Reads a CSV exported from the tracker's "Export CSV" button and produces:
  - a console summary (completion rate, current streak, mood breakdown,
    average energy, correlation between energy and completing the day)
  - a PNG chart showing daily completion + a rolling energy trend

This is meant to demonstrate a full, working analytics slice on top of
the product's own data export - not a toy: it runs against real export
files with the same columns the app actually produces.

Usage:
    python analyze_progress.py --input sample_data/sample_export.csv --output out/
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless-safe: no display server required
import matplotlib.pyplot as plt
import pandas as pd


def load_export(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    bool_cols = ["Completed", "Workouts", "Outdoor", "Diet", "Water", "Reading", "Photo"]
    for col in bool_cols:
        if col in df.columns:
            df[col] = df[col].astype(str).str.lower().map({"true": True, "false": False}).fillna(False)
    df["Challenge Date"] = pd.to_datetime(df["Challenge Date"], errors="coerce")
    df = df.sort_values("Day").reset_index(drop=True)
    return df


def current_streak(df: pd.DataFrame) -> int:
    streak = 0
    for completed in df["Completed"]:
        streak = streak + 1 if completed else 0
    return streak


def longest_streak(df: pd.DataFrame) -> int:
    longest = running = 0
    for completed in df["Completed"]:
        running = running + 1 if completed else 0
        longest = max(longest, running)
    return longest


def summarize(df: pd.DataFrame) -> dict:
    total_days = len(df)
    completed_days = int(df["Completed"].sum())
    completion_rate = completed_days / total_days if total_days else 0.0

    mood_counts = df.loc[df["Mood"].notna() & (df["Mood"] != ""), "Mood"].value_counts().to_dict()
    avg_energy_all = df["Energy"].mean()
    avg_energy_completed = df.loc[df["Completed"], "Energy"].mean()
    avg_energy_missed = df.loc[~df["Completed"], "Energy"].mean()

    return {
        "total_days_logged": total_days,
        "completed_days": completed_days,
        "completion_rate": round(completion_rate * 100, 1),
        "current_streak": current_streak(df),
        "longest_streak": longest_streak(df),
        "mood_breakdown": mood_counts,
        "avg_energy_overall": round(float(avg_energy_all), 2) if pd.notna(avg_energy_all) else None,
        "avg_energy_on_completed_days": round(float(avg_energy_completed), 2) if pd.notna(avg_energy_completed) else None,
        "avg_energy_on_missed_days": round(float(avg_energy_missed), 2) if pd.notna(avg_energy_missed) else None,
    }


def print_summary(summary: dict, challenge_label: str) -> None:
    print(f"\n=== {challenge_label} progress summary ===")
    print(f"Days logged:        {summary['total_days_logged']}")
    print(f"Days completed:     {summary['completed_days']} ({summary['completion_rate']}%)")
    print(f"Current streak:     {summary['current_streak']} days")
    print(f"Longest streak:     {summary['longest_streak']} days")
    if summary["avg_energy_overall"] is not None:
        print(f"Average energy:     {summary['avg_energy_overall']}/10")
    if summary["avg_energy_on_completed_days"] is not None and summary["avg_energy_on_missed_days"] is not None:
        print(
            f"Energy on completed vs. missed days: "
            f"{summary['avg_energy_on_completed_days']} vs {summary['avg_energy_on_missed_days']}"
        )
    if summary["mood_breakdown"]:
        print("Mood breakdown:")
        for mood, count in summary["mood_breakdown"].items():
            print(f"  {mood}: {count}")


def make_chart(df: pd.DataFrame, out_path: Path, challenge_label: str) -> Path:
    fig, ax1 = plt.subplots(figsize=(10, 4.5))

    colors = ["#44624a" if c else "#e3d9c8" for c in df["Completed"]]
    ax1.bar(df["Day"], [1] * len(df), color=colors, width=0.9)
    ax1.set_ylim(0, 1.4)
    ax1.set_yticks([])
    ax1.set_xlabel("Challenge day")
    ax1.set_title(f"{challenge_label}: daily completion + energy trend")

    ax2 = ax1.twinx()
    rolling_energy = df["Energy"].rolling(window=5, min_periods=1).mean()
    ax2.plot(df["Day"], rolling_energy, color="#c69749", linewidth=2.5, label="Energy (5-day avg)")
    ax2.set_ylim(0, 10)
    ax2.set_ylabel("Energy (1-10, 5-day rolling avg)")
    ax2.legend(loc="upper left")

    fig.tight_layout()
    out_path.mkdir(parents=True, exist_ok=True)
    chart_path = out_path / "progress_chart.png"
    fig.savefig(chart_path, dpi=150)
    plt.close(fig)
    return chart_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Path to an exported CSV from the tracker")
    parser.add_argument("--output", default="analytics/out", help="Directory to write the chart into")
    args = parser.parse_args()

    df = load_export(args.input)
    if df.empty:
        raise SystemExit(f"No rows found in {args.input}")

    challenge_label = str(df["Challenge"].iloc[0]) if "Challenge" in df.columns else "Challenge"
    summary = summarize(df)
    print_summary(summary, challenge_label)

    chart_path = make_chart(df, Path(args.output), challenge_label)
    print(f"\nSaved chart to {chart_path}")


if __name__ == "__main__":
    main()
