"""
generate_sample_data.py
------------------------------------------------------------------
Generates a synthetic sample_export.csv matching the exact column
layout produced by the tracker's "Export CSV" button, so the analytics
script has something realistic to run against without needing a real
person's private journal data.

This is committed alongside its own output on purpose: a reviewer can
re-run it to regenerate the sample, or tweak the parameters to see how
analyze_progress.py responds to different completion/mood patterns.

Usage:
    python generate_sample_data.py --days 45 --seed 7 --out sample_data/sample_export.csv
"""

from __future__ import annotations

import argparse
import csv
import random
from datetime import date, timedelta

HEADER = [
    "Challenge", "Day", "Day 1 Date", "Challenge Date", "Quote", "Completed",
    "Workouts", "Outdoor", "Diet", "Water", "Reading", "Photo",
    "Water Actual", "Pages Read", "Mood", "Energy", "Weight",
    "Workout Notes", "Meals", "Journal", "Last Saved",
]

MOODS = ["\U0001F60A Great", "\U0001F642 Good", "\U0001F610 Okay", "\U0001F629 Hard day", "\U0001F525 Motivated"]
QUOTE = "Small daily choices are the compound interest of self-respect."
WORKOUT_NOTES = ["30 min walk", "Yoga flow", "Full body strength", "Rest / stretching", "Dance cardio"]
MEALS = ["Oatmeal, salad, grilled chicken", "Smoothie, soup, stir fry", "Eggs, wrap, pasta"]
JOURNAL_LINES = [
    "Felt good today, energy was steady.",
    "A little tired but pushed through.",
    "Struggled with water intake, need to refill more often.",
    "Great mood after the workout.",
    "Short on time, kept it simple.",
]


def build_rows(total_days: int, seed: int) -> list[list]:
    rng = random.Random(seed)
    start = date(2026, 1, 1)
    rows = []
    # Simulate a realistic pattern: strong start, a rough patch mid-way,
    # recovering toward the end - more useful for demoing trend charts
    # than pure random noise.
    for day in range(1, total_days + 1):
        challenge_date = start + timedelta(days=day - 1)
        if day <= 10:
            complete_chance = 0.9
        elif day <= 20:
            complete_chance = 0.55
        else:
            complete_chance = 0.85

        completed = rng.random() < complete_chance
        workouts = completed or rng.random() < 0.5
        diet = completed or rng.random() < 0.6
        water = completed or rng.random() < 0.5
        reading = completed or rng.random() < 0.7

        energy = max(1, min(10, round(rng.gauss(6.5 if completed else 4.5, 1.5))))
        mood = rng.choice(MOODS) if rng.random() > 0.05 else ""

        rows.append([
            "75 SOFT",
            day,
            start.isoformat(),
            challenge_date.isoformat(),
            QUOTE,
            completed,
            workouts,
            False,
            diet,
            water,
            reading,
            rng.random() < 0.3,
            f"{rng.randint(48, 80)} oz",
            rng.randint(5, 20),
            mood,
            energy,
            "",
            rng.choice(WORKOUT_NOTES) if workouts else "",
            rng.choice(MEALS),
            rng.choice(JOURNAL_LINES) if rng.random() > 0.2 else "",
            f"{challenge_date.isoformat()}T20:{rng.randint(10, 59):02d}:00",
        ])
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--days", type=int, default=45, help="Number of days to generate")
    parser.add_argument("--seed", type=int, default=7, help="Random seed for reproducibility")
    parser.add_argument("--out", default="sample_data/sample_export.csv", help="Output CSV path")
    args = parser.parse_args()

    rows = build_rows(args.days, args.seed)
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(HEADER)
        writer.writerows(rows)

    print(f"Wrote {len(rows)} synthetic rows to {args.out}")


if __name__ == "__main__":
    main()
